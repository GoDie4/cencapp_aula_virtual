export interface Rol {
  id?: number
  nombre: string
  createdAt?: Date
  updatedAt?: Date
  // usuario: Usuario
}