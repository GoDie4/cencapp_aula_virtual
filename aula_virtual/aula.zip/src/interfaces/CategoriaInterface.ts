export interface Categoria {
  id?: number
  nombre: string
  url_imagen: string
  createdAt?: Date
  updatedAt?: Date
}