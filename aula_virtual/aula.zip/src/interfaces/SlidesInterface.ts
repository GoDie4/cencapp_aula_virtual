export interface slidesValues {
  id: string;
  imagen1: string;
  titulo1: string;
  descripcion: string;
}
