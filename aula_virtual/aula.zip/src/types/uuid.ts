declare module 'uuid'
