import React from "react";

export const LoaderSubmit = () => {
  return <div className="loaderSubmit"></div>;
};
