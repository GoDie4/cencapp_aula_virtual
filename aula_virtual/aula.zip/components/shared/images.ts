import logo from '../../assets/logo/logo.png'
import s1 from '../../assets/servicios/servicio1.webp'
import s2 from '../../assets/servicios/servicio2.webp'
import s3 from '../../assets/servicios/servicio3.webp'
import s4 from '../../assets/servicios/servicio4.webp'
import logo_white from '../../assets/logo/logo-white.png'
import ico_white from '../../assets/logo/ico-white.png'
import slide1 from '../../assets/slide/slider1.webp'
import slide2 from '../../assets/slide/slider2.webp'
import st1 from '../../assets/nosotros/contacto.webp'
import lp from '../../assets/varios/logos-peru.svg'

export {
  logo, slide1, slide2, logo_white, ico_white, s1, s2, s3, s4, st1, lp
}
