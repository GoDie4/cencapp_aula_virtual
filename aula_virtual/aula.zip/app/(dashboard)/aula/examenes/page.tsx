import { NextPage } from 'next'


const Page: NextPage = () => {
  return <div>Examenes</div>
}

export default Page