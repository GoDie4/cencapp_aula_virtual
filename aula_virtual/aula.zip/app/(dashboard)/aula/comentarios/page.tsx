import { NextPage } from 'next'


const Page: NextPage = () => {
  return <div>Comentarios</div>
}

export default Page