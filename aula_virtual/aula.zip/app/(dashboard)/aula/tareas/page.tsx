import { NextPage } from 'next'


const Page: NextPage = () => {
  return <div>Tareas</div>
}

export default Page