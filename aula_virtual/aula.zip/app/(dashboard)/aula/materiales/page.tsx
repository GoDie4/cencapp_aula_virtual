import { NextPage } from 'next'


const Page: NextPage = () => {
  return <div>Materiales</div>
}

export default Page