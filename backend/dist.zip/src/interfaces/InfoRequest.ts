export interface InfoRequest {
  email: string,
  phone: string,
  id: string
}