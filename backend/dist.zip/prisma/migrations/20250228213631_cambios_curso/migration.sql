-- AlterTable
ALTER TABLE `cursos` MODIFY `certificacion` TEXT NOT NULL DEFAULT '',
    MODIFY `dirigido` TEXT NOT NULL DEFAULT '',
    MODIFY `metodologia` TEXT NOT NULL DEFAULT '',
    MODIFY `presentacion` TEXT NOT NULL DEFAULT '';
